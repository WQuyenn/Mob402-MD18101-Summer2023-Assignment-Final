const express = require('express');
const userModel = require('../model/userModel');
const app = express();
const bcrypt = require('bcrypt');

app.use(express.urlencoded({ extended: true }));
app.get('/user', (req, res) => {
    res.render('addOrEdit', { title: 'Add User', });
});
//Validate
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
//Add data
app.post('/user/add', async (req, res) => {
    if (req.body.id == '') {
        //Nếu id trống thì thêm mới user
        addRecord(req, res);
    } else {
        //Nếu có id thì thực hiện update theo id
        // updateRecord();
        console.log('Thuc hien update');
        updateRecord(req, res);
    }

});
//Add user
// async function addRecord(req, res) {
//     const { email, user, pass, role } = req.body;
//     console.log(role)
//     if (role != "admin" && role != "user") {
//         return res.render('addOrEdit', { title: "Role only admin or user" })
//     }
//     if (!isValidEmail(email)) {
//         res.render('addOrEdit', { title: "Email is not valid" });
//         return;
//     }
//     // if (user =="" && password =="") {
//     //     res.render('addOrEdit', { title: "User and Password are required" });
//     //     return;
//     // }
//     try {
//         //Lấy thông tin nhập vào

//         const u = new userModel({
//             // _id: req.body.idsp,
//             user: req.body.user,
//             pass: req.body.pass,
//             email: req.body.email,
//             phone: req.body.phone,
//             address: req.body.address,
//             role: req.body.role,
//             // anh: req.file.filename
//         })
//         await u.save() //Thêm vào trong database
//         userModel.find({}).then(users => {
//             res.render('../views/addOrEdit.hbs',
//                 {
//                     title: 'Add successfully',

//                     users: users.map(users => users.toJSON())
//                 })
//         })

//     } catch (error) {
//         console.log("Thêm thất bại", error)
//     }

// }
async function addRecord(req, res) {
    const { email, user, pass, role } = req.body;
    console.log(role);
    if (role !== "admin" && role !== "user") {
        return res.render('addOrEdit', { title: "Role only admin or user" });
    }
    if (!isValidEmail(email)) {
        res.render('addOrEdit', { title: "Email is not valid" });
        return;
    }
    try {
        const u = new userModel({
            user: user,
            pass: pass,
            email: email,
            phone: req.body.phone,
            address: req.body.address,
            role: role,
        });
        console.log(u);
        await u.save();
        userModel.find({}).then((users) => {
            res.render('../views/addOrEdit.hbs', {
                title: 'Add successfully',
                users: users.map((user) => user.toJSON()),
            });
        });
    } catch (error) {
        console.log("Thêm thất bại", error);
        // Xử lý lỗi ở đây, ví dụ:
        res.render('addOrEdit', { title: "Failed to add" });
    }
}

//Update user

function updateRecord(req, res) {
    const { email, user, pass, role } = req.body;

    if (role != "admin" && role != "user") {
        return res.render('addOrEdit', { title: "Role only admin or user" })
    }

    if (!isValidEmail(email)) {
        res.render('addOrEdit', { title: "Email is not valid" });
        return;
    }
    if (user === "" || pass === "") {
        res.render('addOrEdit', { title: "User and Password are required" });
        return;
    }
    userModel.findOneAndUpdate({ _id: req.body.id }, req.body, { new: true }).then((err, doc) => {
        try {
            userModel.find({}).then(users => {
                res.render('../views/addOrEdit.hbs',
                    { title: "Update user" },
                    {
                        users: users.map(user => user.toJSON())
                    })
            })
        } catch (err) {
            console.log(err)
            res.render('addOrEdit', { title: "Update Faided" });
        }
    })
}
//delete user
app.get('/user/delete/:id', async (req, res) => {
    try {
        const user = await userModel.findByIdAndDelete(req.params.id, req.body);
        if (!user) response.status(404).send("No item");
        else {

            res.redirect('/user/list')
        }
        res.status(200).send();
    } catch (err) {
        res.status(500).send(error);

    }


});
// Login
app.get('/', (req, res) => {
    res.render('login', {
        layout: 'mLogin',
        show: false,
        message: '',
    });
});

app.post('/login', async (req, res) => {
    const { user, password } = req.body;


    // if (user == "admin" && password == "admin") {
    //     return res.redirect('/user/list');

    // }
    try {

        const username = await userModel.findOne({ user });
        console.log(username);

        if (!username) {
            res.status(401).send('Tên người dùng không tồn tại');
            return;
        }

        await bcrypt.compare(password, username.pass);

        if (password != username.pass) {
            res.status(401).send('Mật khẩu không chính xác');
            return;
        }
        if (username.role == "admin") {
            return res.redirect('/user/list');
        }
        if (username.role == "user") {
            return res.redirect('/home');
        }
        // res.sendStatus(200);
    } catch (error) {
        console.error('Lỗi khi đăng nhập:', error);
        res.status(500).send('Lỗi máy chủ');
    }

});


app.get('/user/list', (req, res) => {
    try {
        userModel.find({}).then(users => {
            res.render('listUsers', {
                title: "List User",
                users: users.map(user => user.toJSON())
            });
        });
    } catch (error) {
        console.log(error);
    }

});
//Logout
app.get('/logout', (req, res) => {
    res.render('logout');
});
app.get('/logoutUser', (req, res) => {
    res.render('logout', { layout: 'mHome' });
});
//Edit User

app.get('/user/edit/:id', async (req, res) => {
    try {
        const user = await userModel.findById(req.params.id);
        res.render('addOrEdit', {
            title: "Update User",
            user: user.toJSON()
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});
//User chi tiet
app.get('/user/:id', async (req, res) => {
    try {
        const user = await userModel.findById(req.params.id);
        if (!user) {
            return res.status(404).send('User not found');
        }

        const options = {
            allowProtoPropertiesByDefault: true,
            allowProtoMethodsByDefault: true
        };

        res.render('user', { user }, options);
        console.log(user);
    } catch (error) {
        res.status(500).send('Error retrieving user');
    }
});
module.exports = app;