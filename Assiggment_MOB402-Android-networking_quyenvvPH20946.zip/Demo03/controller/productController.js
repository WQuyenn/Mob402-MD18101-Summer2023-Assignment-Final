const express = require('express');
const app = express();
const bcrypt = require('bcrypt');
const multer = require('multer')

const productModel = require('../model/productModel');
app.use(express.urlencoded({ extended: true }));
var storage = multer.diskStorage({
    destination :(req, file, cb) => {
        cb(null, 'images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now()+'-'+file.originalname)
    }
})
const upload = multer({storage: storage, limits:{fieldSize: 1*1024*1024}});
app.use(express.static(__dirname + '/images/'))

app.get('/product', (req, res) => {
    res.render('addOrEditProducts');
});
//Add data
app.post('/product/add',upload.single('anh'), async (req, res) => {
    if (req.body.id == '') {
        //Nếu id trống thì thêm mới user
        addRecord(req, res);
    } else {
        //Nếu có id thì thực hiện update theo id
        // updateRecord();
        console.log('Thuc hien update');
        updateRecord(req, res);
    }

});
//Add product
// async function addRecord(req, res) {
//     const p = new productModel({
//         // _id: req.body.idsp,
//         name: req.body.name,
//         price: req.body.price,
//         description: req.body.description,
//         anh: req.file.filename
//     }) //Lấy thông tin nhập vào
//     try {
//         await p.save() //Thêm vào trong database
//         productModel.find({}).then(products => {
//             res.render('../views/addOrEditProducts.hbs',
//                 {
//                     title: 'Add successfully',

//                     products: products.map(products => products.toJSON())
//                 })
//         })

//     } catch (error) {
//         console.log(error)
//     }

// }
async function addRecord(req, res) {
    const { name, price, description } = req.body;
    try {
      const p = new productModel({
        name: name,
        price: price,
        description: description,
        anh: req.file.filename
      });
      await p.save();
      productModel.find({}).then((products) => {
        res.render('../views/addOrEditProducts.hbs', {
          title: 'Add successfully',
          products: products.map((product) => product.toJSON())
        });
      });
    } catch (error) {
      console.error(error);
      res.render('addOrEditProducts', { title: "Failed to add product" });
    }
  }

//Update user

function updateRecord(req, res) {
    productModel.findOneAndUpdate({ _id: req.body.id }, req.body, { new: true }).then((err, doc) => {
        try {
            productModel.find({}).then(products => {
                res.render('../views/addOrEditProducts.hbs', {
                    products: products.map(product => product.toJSON())
                })
            })
        } catch (err) {
            console.log(err)
            res.render('addOrEditProducts', { title: "Update Faided" });
        }
    })
}
//delete user
app.get('/product/delete/:id', async (req, res) => {
    try {
        const product = await productModel.findByIdAndDelete(req.params.id, req.body);
        if (!product) response.status(404).send("No item");
        else {

            res.redirect('/product/list')
        }
        res.status(200).send();
    } catch (err) {
        res.status(500).send(error);

    }


});

//View list user
// app.get('/list', (req, res) => {
//     res.render('listUsers',{title: "List User"});
// });
app.get('/product/list', (req, res) => {
    try {
        productModel.find({}).then(products => {
            res.render('listProducts', {
                title: "List Products",
                products: products.map(product => product.toJSON())
            });
        });
    } catch (error) {
        console.log(error);
    }

});

app.get('/home', (req, res) => {
   
    try {
        productModel.find({}).then(products => {
            res.render('home', {
                layout:'mHome',
                products: products.map(product => product.toJSON())
            });
        });
    } catch (error) {
        console.log(error);
    }

});
//Edit User

app.get('/product/edit/:id', async (req, res) => {
    try {
        const product = await productModel.findById(req.params.id);
        res.render('addOrEditProducts', {
            title: "Update Product",
            product: product.toJSON()
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});

//Hien user chi tiet
app.get('/product/:id', async (req, res) => {
    try {
        const product = await productModel.findById(req.params.id);
        if (!product) {
            return res.status(404).send('User not found');
        }

        res.render('product', { product });
    } catch (error) {
        res.status(500).send('Error retrieving user');
    }
});
module.exports = app;