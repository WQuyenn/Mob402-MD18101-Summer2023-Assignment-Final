const express = require('express');
const userModel = require('../model/userModel');
const app = express();


//Add data
app.post('/add', async (req, res) => {
    const u = new userModel(req.body);
    try {
        await u.save();
        res.send(u);
    } catch (error) {
        res.status(404).send(error);
    }
})

//Get all data
app.get('/list', async (req, res) => {
    const users = await userModel.find({});
    try {
        res.send(users);
    } catch (error) {
        res.status(404).send(error);
    }
});

//Update user
app.patch('/updateUser/:id', async (req, res) => {
    try {
        const user = await userModel.findByIdAndUpdate(req.params.id, req.body);
        await userModel.save();
        res.send(user);
    } catch (error) {
        res.status(404).send(error);
    }
});
//Delete user
app.delete('/deleteUser/:id', async (req, res) => {
    try {
        const user = await userModel.findByIdAndDelete(req.params.id, req.body);
        if (!user)  {
            res.status(404).send("404 not found");
        }
        res.status(200).send();
    } catch (error) {
        res.status(404).send(error);
    }
});
module.exports = app;