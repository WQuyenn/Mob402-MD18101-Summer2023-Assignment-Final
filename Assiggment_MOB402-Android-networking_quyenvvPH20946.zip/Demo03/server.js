const express = require('express');
const app = express();
// const userRouter= require('../Demo03/router/userRouter');
const userController = require('../Demo03/controller/userController');
const productController = require('../Demo03/controller/productController');
const  mongoose  = require('mongoose');
const port = 8000;
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const userModel = require('./model/userModel');
const bcrypt = require('bcrypt');
const url = 'mongodb+srv://quyenvv:quyenvv123@cluster0.ouxba2p.mongodb.net/MongoDemo03';

mongoose.connect(url, {useUnifiedTopology: true, useNewUrlParser: true});

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.engine('.hbs', exphbs.engine({ extname: '.hbs', defaultLayout: "main",}));
app.set('view engine', '.hbs');
app.use(express.json());
// app.use(userRouter);
app.use('/',userController);
app.use('/', productController);


// // Đăng ký người dùng mới
// app.post('/register', async (req, res) => {
//     const { username, password } = req.body;
  
//     try {
//       const existingUser = await User.findOne({ username });
  
//       if (existingUser) {
//         res.status(409).send('Tên người dùng đã tồn tại');
//         return;
//       }
  
//       const hashedPassword = await bcrypt.hash(password, 10);
  
//       await userModel.create({ username, password: hashedPassword });
  
//       res.sendStatus(201);
//     } catch (error) {
//       console.error('Lỗi khi đăng ký người dùng:', error);
//       res.status(500).send('Lỗi máy chủ');
//     }
//   });
 

app.listen(port, () => {
    console.log('connect sucessfully',{port});
  })
