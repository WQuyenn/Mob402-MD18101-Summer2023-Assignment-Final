const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    user: {
        type: 'String',
        required: true,
    },
    pass: {
        type: 'String',
        required: true,
    },
    email:{
        type:'String'
    },
    phone:{
        type:'Number'
    },
    address:{
        type:'String'
    },
    role:{
        type:'String'
    }

});
const userModel = new mongoose.model('Users', userSchema);
module.exports = userModel;
