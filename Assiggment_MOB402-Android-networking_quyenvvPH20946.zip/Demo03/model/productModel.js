const mongoose = require('mongoose');

const productSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    price:{
        type:Number
    },
    description:{
        type:String
    },
    anh:{
        type:String
    }

});
const productModel = new mongoose.model('products', productSchema);
module.exports = productModel;
